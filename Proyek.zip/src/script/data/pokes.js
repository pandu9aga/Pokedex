const pokes = [
    {
        name: "Zapdos",
        fanArt: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/145.png",
        base_experience:178,
        height:11,
        order:16,
        weight:320
    },
    {
        name: "Articuno",
        fanArt: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/144.png",base_experience:178,
        height:11,
        order:16,
        weight:320
    },
    {
        name: "Moltres",
        fanArt: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/146.png",base_experience:178,
        height:11,
        order:16,
        weight:320
    },
    {
        name: "Dialga",
        fanArt: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/483.png",base_experience:178,
        height:11,
        order:16,
        weight:320
    },
    {
        name: "Palkia",
        fanArt: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/484.png",base_experience:178,
        height:11,
        order:16,
        weight:320
    },
    {
        name: "Rayquaza",
        fanArt: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/384.png",base_experience:178,
        height:11,
        order:16,
        weight:320
    },
    {
        name: "Lugia",
        fanArt: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/249.png",base_experience:178,
        height:11,
        order:16,
        weight:320
    }
];

    export default pokes;
